import { Note, Theme, SecurityQA } from '../types';

const STORAGE_KEY_AUTH = 'kasa_auth_v1';
const STORAGE_KEY_DATA = 'kasa_data_v1';
const STORAGE_KEY_THEME = 'kasa_theme_v1';
const STORAGE_KEY_QA = 'kasa_qa_v1';

/**
 * Simple obfuscation to prevent casual reading of data in LocalStorage.
 */
const encode = (str: string): string => {
  try {
    return btoa(encodeURIComponent(str));
  } catch (e) {
    console.error("Encoding error", e);
    return str;
  }
};

const decode = (str: string): string => {
  try {
    return decodeURIComponent(atob(str));
  } catch (e) {
    console.error("Decoding error", e);
    return "";
  }
};

// Helper for normalizing strings (Turkish support)
const normalize = (str: string): string => {
  return str.trim().toLocaleLowerCase('tr-TR');
};

// --- AUTH ---

export const hasMasterPassword = (): boolean => {
  return !!localStorage.getItem(STORAGE_KEY_AUTH);
};

export const setMasterPassword = (password: string): void => {
  const hash = encode(password + "_kasa_salt"); 
  localStorage.setItem(STORAGE_KEY_AUTH, hash);
};

export const verifyPassword = (password: string): boolean => {
  const stored = localStorage.getItem(STORAGE_KEY_AUTH);
  if (!stored) return false;
  return stored === encode(password + "_kasa_salt");
};

// --- SECURITY QUESTION ---

export const setSecurityQA = (question: string, answer: string): void => {
  // Store question in plain text (encoded base64 for basic hiding)
  // Store answer hashed
  const data: SecurityQA = {
    question: encode(question),
    answerHash: encode(normalize(answer) + "_kasa_qa_salt")
  };
  localStorage.setItem(STORAGE_KEY_QA, JSON.stringify(data));
};

export const getSecurityQuestion = (): string | null => {
  const stored = localStorage.getItem(STORAGE_KEY_QA);
  if (!stored) return null;
  try {
    const data: SecurityQA = JSON.parse(stored);
    return decode(data.question);
  } catch (e) {
    return null;
  }
};

export const verifySecurityAnswer = (answer: string): boolean => {
  const stored = localStorage.getItem(STORAGE_KEY_QA);
  if (!stored) return false;
  try {
    const data: SecurityQA = JSON.parse(stored);
    const checkHash = encode(normalize(answer) + "_kasa_qa_salt");
    return data.answerHash === checkHash;
  } catch (e) {
    return false;
  }
};

// --- DATA ---

export const saveNotes = (notes: Note[]): void => {
  const json = JSON.stringify(notes);
  localStorage.setItem(STORAGE_KEY_DATA, encode(json));
};

export const getNotes = (): Note[] => {
  const stored = localStorage.getItem(STORAGE_KEY_DATA);
  if (!stored) return [];
  try {
    const json = decode(stored);
    return JSON.parse(json);
  } catch (e) {
    return [];
  }
};

export const resetApp = (): void => {
  localStorage.removeItem(STORAGE_KEY_AUTH);
  localStorage.removeItem(STORAGE_KEY_DATA);
  localStorage.removeItem(STORAGE_KEY_QA);
  // We keep the theme preference
  window.location.reload();
};

// --- THEME ---

export const getTheme = (): Theme => {
  const stored = localStorage.getItem(STORAGE_KEY_THEME);
  // Default to dark mode if not set
  return (stored as Theme) || 'dark';
};

export const setTheme = (theme: Theme): void => {
  localStorage.setItem(STORAGE_KEY_THEME, theme);
  if (theme === 'dark') {
    document.documentElement.classList.add('dark');
  } else {
    document.documentElement.classList.remove('dark');
  }
};